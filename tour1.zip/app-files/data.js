var APP_DATA = {
  "scenes": [
    {
      "id": "0-marma-points-chart",
      "name": "Marma-Points-Chart",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": -0.955178019084471,
        "pitch": 0.08763175609809437,
        "fov": 1.4874558877949153
      },
      "linkHotspots": [
        {
          "yaw": 1.1283508748272766,
          "pitch": 0.2080328812049057,
          "rotation": 0,
          "target": "1-panorama_norges-kristelige-studentforbund-redigert_2024-09-23-15-42-03-min"
        },
        {
          "yaw": 3.1052238457434216,
          "pitch": 0.08221477315634118,
          "rotation": 0,
          "target": "2-panorama_norges-kristelige-studentforbund-redigert_2024-09-23-16-07-14"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-panorama_norges-kristelige-studentforbund-redigert_2024-09-23-15-42-03-min",
      "name": "Panorama_Norges Kristelige Studentforbund Redigert_2024-09-23-15-42-03-min",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        },
        {
          "tileSize": 512,
          "size": 4096
        }
      ],
      "faceSize": 4096,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "2-panorama_norges-kristelige-studentforbund-redigert_2024-09-23-16-07-14",
      "name": "Panorama_Norges Kristelige Studentforbund Redigert_2024-09-23-16-07-14",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        },
        {
          "tileSize": 512,
          "size": 4096
        }
      ],
      "faceSize": 4096,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
